#! /bin/bash
echo enter CD number
read Cdnumber
echo $Cdnumber >> file.txt
echo moviename
read moviename
echo $moviename >> file.txt
echo language
read language
echo $language >> file.txt
echo date
read date
echo $date >> file.txt
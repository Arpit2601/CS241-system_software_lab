#! /bin/bash
num_of_lines=$(wc -l "$1")
#echo $num_of_lines
##################
word_count(){
sum=0
while read p
do 
    sum=$((sum+1))
    #echo $sum
done < $1
echo $sum
}
word_count $1
#why is last echo not printing correct sum why zero

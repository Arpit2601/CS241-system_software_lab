#include<iostream>
#include "function.h"
using namespace std;
void printhello()
{
	cout<<"Hello world and bye "<<endl;
}
#include<iostream>
#include "function.h"
using namespace std;

int main()
{
	printhello();
	cout<<"factorial of 6 is "<<factorial(6)<<endl;
	int temp;
	temp=5;
	int x=2;
	cout<<temp*x;
	return 0;
}